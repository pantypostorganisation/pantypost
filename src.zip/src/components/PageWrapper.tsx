// src/components/PageWrapper.tsx
'use client';

export default function PageWrapper({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}